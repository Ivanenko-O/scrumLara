<meta name="description" content="Мастера Scrum - оптимизации бизнеса. Свяжитесь с нами, и мы поможем Вам сделаться более Agile."/>
<meta name="author" content="Andrii Pavlenko"/>