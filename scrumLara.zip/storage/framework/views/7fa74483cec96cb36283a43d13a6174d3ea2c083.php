<?php $__env->startSection('content'); ?>
<h1> <?php echo e($post->title); ?></h1>
<?php echo $post->body; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>