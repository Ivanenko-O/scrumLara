<?php $__env->startSection('content'); ?>

    
    <section id="page-title">
        <div class="container clearfix">
            <h1> <?php echo e($post->title); ?> </h1>
            <ol class="breadcrumb">
                <li><a href="">Главная</a></li>
                <li><a href="blog">Блог</a></li>
                <li class="active">Статья</li>
            </ol>
        </div>
    </section>
    
    <section id="content">

        <div class="content-wrap">

            <div class="container clearfix">

                <!-- Post Content -->
                <div class="postcontent nobottommargin clearfix">

                    <div class="single-post nobottommargin">

                        <!-- Single Post -->
                        <div class="entry clearfix">

                            <?php echo $post->body; ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>