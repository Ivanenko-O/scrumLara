@extends('index')
@section('title', 'Тренинг "Management30" - Agile практики для менеджеров и Scrum-мастеров')

@section('meta')
    @include('pages.management30.meta')
@endsection

@section('content')
    @include('pages.management30.content')
@endsection