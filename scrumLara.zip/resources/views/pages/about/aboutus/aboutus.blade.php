@extends('index')
@section('title', 'О компании Scrummasters - Мастера Scrum оптимизации бизнеса')

@section('meta')
    @include('pages.about.aboutus.meta')
@endsection

@section('content')
    @include('pages.about.aboutus.content')
@endsection
