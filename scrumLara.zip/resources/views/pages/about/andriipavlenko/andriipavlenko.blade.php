@extends('index')
@section('title', 'Андрей Павленко - Agile Scrum Management30 – тренер эксперт и практик')

@section('meta')
    @include('pages.about.andriipavlenko.meta')
@endsection

@section('content')
    @include('pages.about.andriipavlenko.content')
@endsection
