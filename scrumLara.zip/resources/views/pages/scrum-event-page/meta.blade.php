<meta name="description" content="Шаблон описания">
<meta name="author" content=""/>