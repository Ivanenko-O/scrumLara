@extends('index')
@section('title', 'Шаблон страницы - Scrummasters')

@section('meta')
    @include('pages.scrum-event-page.meta')
@endsection

@section('content')
    @include('pages.scrum-event-page.content')
@endsection