<meta name="description" content="Все тренинги. Ближайшие тренинги. Обучение Scrum Agile Management30 Lean в Киеве и Украине.">
<meta name="author" content="Andrii Pavlenko"/>
