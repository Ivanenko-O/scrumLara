@extends('index')
@section('title', 'Список всех тренингов - Agile Scrum Management30')

@section('meta')
    @include('pages.eventlist.meta')
@endsection

@section('content')
    @include('pages.eventlist.content')
@endsection