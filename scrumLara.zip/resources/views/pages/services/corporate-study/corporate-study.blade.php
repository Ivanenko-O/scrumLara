@extends('index')
@section('title', 'Корпоративные тренинги по Scrum Agile Management30')

@section('meta')
    @include('pages.services.corporate-study.meta')
@endsection

@section('content')
    @include('pages.services.corporate-study.content')
@endsection