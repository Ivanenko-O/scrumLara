<meta name="description" content="Тренинги для команд. Обучение менеджмента. Тестирование сотрудников. Заказ индивидуальной программы тренингов." />
<meta name="author" content="Andrii Pavlenko"/>