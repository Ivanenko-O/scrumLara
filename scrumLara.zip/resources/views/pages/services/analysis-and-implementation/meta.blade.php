<meta name="description" content="Agile-трансформация бизнеса. Консалтинг. Анализ текущего состояния процессов. Внедрение."/>
<meta name="author" content="Andrii Pavlenko"/>