@extends('index')
@section('title', 'Консалтинг. Анализ. Внедрение Agile Scrum Management30')

@section('meta')
    @include('pages.services.analysis-and-implementation.meta')
@endsection

@section('content')
    @include('pages.services.analysis-and-implementation.content')
@endsection