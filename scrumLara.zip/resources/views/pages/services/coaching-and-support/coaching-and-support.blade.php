@extends('index')
@section('title', 'Коучинг Agile Scrum Management30 Lean')

@section('meta')
    @include('pages.services.coaching-and-support.meta')
@endsection

@section('content')
    @include('pages.services.coaching-and-support.content')
@endsection