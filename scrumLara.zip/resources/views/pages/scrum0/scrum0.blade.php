@extends('index')
@section('title', 'Scrum с нуля - однодневный тренинг - Scrummasters')

@section('meta')
    @include('pages.scrum0.meta')
@endsection

@section('content')
    @include('pages.scrum0.content')
@endsection