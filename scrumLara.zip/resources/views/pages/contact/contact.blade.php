@extends('index')
@section('title', 'Наши контакты - Scrummaster')

@section('meta')
    @include('pages.contact.meta')
@endsection

@section('content')
    @include('pages.contact.content')
@endsection