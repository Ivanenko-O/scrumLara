@extends('index')
@section('title', '404 - Scrummasters')

@section('meta')
    @include('pages.404.meta')
@endsection

@section('content')
    @include('pages.404.content')
@endsection