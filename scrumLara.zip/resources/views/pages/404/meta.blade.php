<meta name="description" content="Страница не найдена.">
<meta name="author" content="Andrii Pavlenko" />