<meta name="description" content="Agile-трансформация Компаний. Открытые и корпоративные тренинги по Scrum Agile Management30 Lean."/>
<meta name="author" content="Andrii Pavlenko"/>
<meta name="google-site-verification" content="ErtxKKWZSOO6qG9O-YAzyOCufAa6945goZIUTWNJK4I"/>