@extends('index')
@section('title', 'Scrummasters - тренинги по Agile Scrum Lean Management30')

@section('meta')
    @include('pages.home.meta')
@endsection

@section('content')
    @include('pages.home.content')
@endsection