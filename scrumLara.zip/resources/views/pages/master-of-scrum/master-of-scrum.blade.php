@extends('index')
@section('title', 'Мастер Scrum - двухдневный тренинг - Scrummasters')

@section('meta')
    @include('pages.master-of-scrum.meta')
@endsection

@section('content')
    @include('pages.master-of-scrum.content')
@endsection