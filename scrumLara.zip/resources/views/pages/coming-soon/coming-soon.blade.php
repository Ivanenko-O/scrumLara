@extends('index')
@section('title', 'Эта страница еще в разработке. Скоро мы ее добавим')

@section('meta')
    @include('pages.coming-soon.meta')
@endsection

@section('content')
    @include('pages.coming-soon.content')
@endsection