<meta name="description" content="Эта страница еще в разработке. Скоро мы ее добавим."/>
<meta name="author" content=""/>