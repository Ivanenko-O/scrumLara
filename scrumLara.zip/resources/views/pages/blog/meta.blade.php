<meta name="description" content="Хотите узнать о Scrum? об Agile? Или, о Management30? - добро пожаловать на блог Scrummasters!"/>
<meta name="author" content="Andrii Pavlenko"/>