@extends('index')
@section('title', 'Бесплатная Agile, Scrum-площадка для обучения')

@section('meta')
    @include('pages.blog.meta')
@endsection

@section('content')
    @include('pages.blog.content')
@endsection