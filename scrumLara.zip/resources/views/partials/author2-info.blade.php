<!-- Post Author Info
                      ============================================= -->
<div class="panel panel-default">
    <div class="panel-heading">
        <h3 class="panel-title">Автор <span><a href="../coming-soon">Анастасия Кочегарова</a></span>
        </h3>
    </div>
    <div class="panel-body">
        <div class="author-image">
            <img src="../images/author/author2.JPG" alt="" class="img-circle">
        </div>
        Бизнес-партнер, психоаналитик, организатор Agile-мероприятий и большого числа Scrum-тренингов.
    </div>
</div><!-- Post Single - Author End -->