<!-- Sidebar
============================================= -->

<div class="widget subscribe-widget clearfix">
    <h5>Подпишитесь на нашу рассылку, чтобы получать статьи на тематику <strong>Agile, Scrum </strong>и наш еженедельный
        дайджест.</h5>
    <div class="widget-subscribe-form-result"></div>
    <form id="widget-subscribe-form" action="../include/subscribe.php" role="form" method="post" class="nobottommargin">
        <div class="input-group divcenter">

            <span class="input-group-addon"><i class="icon-email2"></i></span>
            <input type="email" id="widget-subscribe-form-email" name="widget-subscribe-form-email"
                   class="form-control required email" placeholder="Введите Ваш Email">
            <div class="col-md-12 nopadding">
                                <span class="input-group-btn ">
										<button class="btn btn-green btn-custom" type="submit">Подписаться</button>
								</span>
            </div>
        </div>
    </form>
</div>
<!-- .sidebar end -->