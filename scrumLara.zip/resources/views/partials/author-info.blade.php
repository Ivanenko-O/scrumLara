<!-- Post Author Info
                      ============================================= -->
<div class="panel panel-default">
    <div class="panel-heading">
        <h3 class="panel-title">Автор <span><a href="../about/andriipavlenko">Андрей Павленко</a></span>
        </h3>
    </div>
    <div class="panel-body">
        <div class="author-image">
            <img src="../images/author/author.png" alt="" class="img-circle">
        </div>
        Agile-эксперт и практик, Scrum-тренер и бизнес-наставник, имеющий опыт оптимизации процессов как в сфере IT, так и в смежных областях.
    </div>
</div><!-- Post Single - Author End -->